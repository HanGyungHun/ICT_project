<template>
  <h1>Face Mask Detrction Project</h1>
      <div class="container">
    <label for="fileInput">
      <img :src="imageData.poto" alt="" :style="{ width: imageSize, height: imageSize }" @click.prevent="openFileInput">
      <input type="file" id="fileInput" ref="fileInput" style="display: none" @change="handleFileUpload">
    </label>
    <div class="btn-holder">
      <button type="button" class="btn btn-4 hover-border-6" @click="openFileInput">
        <span>이미지 선택</span>
      </button>
      <button type="button" class="btn btn-4 hover-border-7" @click="analyzeImage">
        <span>이미지 분석</span>
        
      </button>
      
    </div>
  </div>
<!-- SPINNER ORBITS -->
<div class="spinner-box" v-if="loading">
  <div class="blue-orbit leo">
  </div>

  <div class="green-orbit leo">
  </div>
  
  <div class="red-orbit leo">
  </div>
  
  <div class="white-orbit w1 leo">
  </div><div class="white-orbit w2 leo">
  </div><div class="white-orbit w3 leo">
  </div>
</div>


</template>

<script>
import axios from 'axios'
export default {
  
  name: 'App',
  data() {
    return {
      imageSize: '500px',
      base64EncodedImage: '',
      predictedImage: '',
      loading:false,
      imageData: {
        poto: require('@/assets/image.png'),
      }
    };
  },
  methods: {
    imagepasing(){

    },
    handleFileUpload(event) {
      // 파일 업로드 처리
      const input = event.target;
      const files = input.files;
      
      if (files && files.length > 0) {
        // 선택한 파일 정보 업데이트
        const file = files[0];
        const reader = new FileReader();

        reader.onload = () => {
          // 이미지 데이터 URL로 업데이트
          this.imageData.poto = reader.result;
          // 이미지 크기를 동적으로 설정
        };

        // 파일을 읽어옵니다.
        reader.readAsDataURL(file);
      } else {
        console.log('No file selected');
      }
    },
    openFileInput() {
      // 파일 업로드 input 요소를 클릭합니다.
      this.$refs.fileInput.click();
    },
    
    analyzeImage() {
        // 이미지 데이터를 JSON 형식으로 변환
        this.loading=true;
        const src = this.imageData.poto
        const base64Encoded = src.split(',')[1];
        // const data = {
        //   base64Encoded: base64Encoded
        // };
        const data = new FormData();
        data.append('base64Encoded',base64Encoded);
        // Axios를 사용하여 Flask API에 POST 요청 전송
        axios.post('http://localhost:5000/mask', data)
          .then(response => {
            // API로부터의 응답 처리
            console.log('분석 결과:', response.data);

            this.imageData.poto = 'data:image/jpeg;base64,'+response.data.base64
            this.loading=false;
          })
          .catch(error => {
            // 에러 처리
            console.error('이미지 분석 중 에러 발생:', error);
          });
      },
  },
};
</script>

<style>
/* KEYFRAMES */

@keyframes spin {
  from {
    transform: rotate(0);
  }
  to{
    transform: rotate(359deg);
  }
}

@keyframes spin3D {
  from {
    transform: rotate3d(.5,.5,.5, 360deg);
  }
  to{
    transform: rotate3d(0deg);
  }
}

@keyframes configure-clockwise {
  0% {
    transform: rotate(0);
  }
  25% {
    transform: rotate(90deg);
  }
  50% {
    transform: rotate(180deg);
  }
  75% {
    transform: rotate(270deg);
  }
  100% {
    transform: rotate(360deg);
  }
}

@keyframes configure-xclockwise {
  0% {
    transform: rotate(45deg);
  }
  25% {
    transform: rotate(-45deg);
  }
  50% {
    transform: rotate(-135deg);
  }
  75% {
    transform: rotate(-225deg);
  }
  100% {
    transform: rotate(-315deg);
  }
}

@keyframes pulse {
  from {
    opacity: 1;
    transform: scale(1);
  }
  to {
    opacity: .25;
    transform: scale(.75);
  }
}

/* GRID STYLING */

* {
  box-sizing: border-box;
}

.spinner-box {
  width: 500px;
  height: 500px;
  display: flex;
  justify-content: center;
  align-items: center;
  background-color: transparent;
  position:absolute;
  margin-top: -612px;
  margin-left: 51px;
  background-color: rgba(0, 0, 0, 0.8);
}

/* SPINNING CIRCLE */

.leo-border-1 {
  position: absolute;
  width: 150px;
  height: 150px;
  padding: 3px;
  display: flex;
  justify-content: center;
  align-items: center;
  border-radius: 50%;
  background: rgb(63,249,220);
  background: linear-gradient(0deg, rgba(63,249,220,0.1) 33%, rgba(63,249,220,1) 100%);
  animation: spin3D 1.8s linear 0s infinite;
}

.leo-core-1 {
  width: 100%;
  height: 100%;
  background-color: #37474faa;
  border-radius: 50%;
}

.leo-border-2 {
  position: absolute;
  width: 150px;
  height: 150px;
  padding: 3px;
  display: flex;
  justify-content: center;
  align-items: center;
  border-radius: 50%;
  background: rgb(251, 91, 83);
  background: linear-gradient(0deg, rgba(251, 91, 83, 0.1) 33%, rgba(251, 91, 83, 1) 100%);
  animation: spin3D 2.2s linear 0s infinite;
}

.leo-core-2 {
  width: 100%;
  height: 100%;
  background-color: #1d2630aa;
  border-radius: 50%;
}


/* SOLAR SYSTEM */

.solar-system {
  width: 250px;
  height: 250px;
  display: flex;
  justify-content: center;
  align-items: center;
}

.orbit {
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  border: 1px solid #fafbfC;
  border-radius: 50%;
} 

.earth-orbit {
  width: 165px;
  height: 165px;
  -webkit-animation: spin 12s linear 0s infinite;
}

.venus-orbit {
  width: 120px;
  height: 120px;
  -webkit-animation: spin 7.4s linear 0s infinite;
}

.mercury-orbit {
  width: 90px;
  height: 90px;
  -webkit-animation: spin 3s linear 0s infinite;
}

.planet {
  position: absolute;
  top: -5px;
  width: 10px;
  height: 10px;
  border-radius: 50%;
  background-color: #3ff9dc;
}

.sun {
  width: 35px;
  height: 35px;
  border-radius: 50%;
  background-color: #ffab91;
}

.leo {
  position: absolute;
  display: flex;
  justify-content: center;
  align-items: center;
  border-radius: 50%;
}

.blue-orbit {
  width: 165px;
  height: 165px;
  border: 1px solid #91daffa5;
  -webkit-animation: spin3D 3s linear .2s infinite;
}

.green-orbit {
  width: 120px;
  height: 120px;
  border: 1px solid #91ffbfa5;
  -webkit-animation: spin3D 2s linear 0s infinite;
}

.red-orbit {
  width: 90px;
  height: 90px;
  border: 1px solid #ffca91a5;
  -webkit-animation: spin3D 1s linear 0s infinite;
}

.white-orbit {
  width: 60px;
  height: 60px;
  border: 2px solid #ffffff;
  -webkit-animation: spin3D 10s linear 0s infinite;
}

.w1 {
  transform: rotate3D(1, 1, 1, 90deg);
}

.w2 {
  transform: rotate3D(1, 2, .5, 90deg);
}

.w3 {
  transform: rotate3D(.5, 1, 2, 90deg);
}

.three-quarter-spinner {
  width: 50px;
  height: 50px;
  border: 3px solid #fb5b53;
  border-top: 3px solid transparent;
  border-radius: 50%;
  animation: spin .5s linear 0s infinite;
}
/*////////////////////////////////////////////////////////////////////////////////////////*/ 

#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
@property --hue {
  initial-value: 0;
  syntax: '<number>';
  inherits: false;
}

@property --eval {
  initial-value: 0;
  syntax: '<number>';
  inherits: false;
}

body {
  width: 100vw;
  height: 100vh;
  overflow: hidden;
  background-color: black;
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  animation: rotate 8s linear infinite both, eval 19s linear infinite both,;
  background-image: 
    radial-gradient(farthest-corner at 0% calc(var(--eval) * 100%), hsla(calc(var(--hue) * 360deg), 70%, 60%, 1), hsla(calc(var(--hue) * 360deg), 70%, 60%, 0) 80%),
    radial-gradient(farthest-corner at calc(var(--eval) * 100%) 100%, hsla(calc((var(--hue) + 0.15) * 360deg), 60%, 60%, 1), hsla(calc((var(--hue) + 0.2) * 360deg), 60%, 60%, 0) 110%),
    radial-gradient(farthest-corner at calc(100% - var(--eval) * 100%) 0%, hsla(calc((var(--hue) + 0.3) * 360deg), 60%, 60%, 1), hsla(calc((var(--hue) + 0.3) * 360deg), 60%, 60%, 0) 100%),
    radial-gradient(farthest-corner at 100% calc(100% - var(--eval) * 100%), hsla(calc((var(--hue) + 0.45) * 360deg), 70%, 60%, 1), hsla(calc((var(--hue) + 0.5) * 360deg), 70%, 60%, 0) 90%);
}

h1 {
  font-size: 10vw;
  background-image: inherit;
  animation: inherit;
  filter: brightness(1.5) drop-shadow(0rem 0.3rem 0rem rgba(0, 0, 0, 0.2));
  background-clip: text;
  -webkit-background-clip: text;
  color: transparent;
}

@keyframes rotate {
  from { --hue: 0; }
  to { --hue: 1; }
}

@keyframes eval {
  0% { --eval: 0; }
  50% { --eval: 1; }
  100% { --eval: 0; }
}






* {
  box-sizing: border-box;
  margin: 0; padding: 0;
}
body {
  font-family: 'Roboto', sans-serif;
  color: rgb(114, 108, 114);
  background-color: rgb(255,255,255);
}
h1 {
  padding: 50px 0;
  font-size: 45px;
  text-align: center;
  color: rgb(54, 56, 55);
}
:active, :hover, :focus {
  outline: 0!important;
  outline-offset: 0;
}
::before,
::after {
  position: absolute;
  content: "";
}

.btn-holder {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  max-width: 1000px;
  margin: 10px auto 35px;
}
.btn {
  position: relative;
  display: inline-block;
  width: auto; height: auto;
  background-color: transparent;
  border: none;
  cursor: pointer;
  margin: 0px 25px 15px;
  min-width: 150px;
}
  .btn span {         
    position: relative;
    display: inline-block;
    font-size: 14px;
    font-weight: bold;
    letter-spacing: 2px;
    text-transform: uppercase;
    top: 0; left: 0;
    width: 100%;
    padding: 15px 20px;
    transition: 0.3s;
  }
  .btn-4 span {
  color: rgb(252, 252, 252);
  background-color: rgb(0, 0, 0);
}
.btn-4 span:hover {
  color: rgb(4, 250, 127);
}
.btn-4::before,
.btn-4::after {
  width: 15%; height: 2px;
  background-color: rgb(0, 255, 128);
  z-index: 2;
}

/* 16. hover-border-6 */
.btn.hover-border-6::before,
.btn.hover-border-6::after {
  top: 0;
  transition: width 0.2s 0.35s ease-out;
}
.btn.hover-border-6::before {
  right: 50%;
}
.btn.hover-border-6::after {
  left: 50%;
}
.btn.hover-border-6:hover::before,
.btn.hover-border-6:hover::after {
  width: 50%;
  transition: width 0.2s ease-in;   
}

.btn.hover-border-6 span::before,
.btn.hover-border-6 span::after {
  width: 0%; height: 0%;
  background: transparent;
  opacity: 0;
  z-index: 2;
  transition: width 0.2s ease-in, height 0.15s 0.2s linear, opacity 0s 0.35s;
}
.btn.hover-border-6 span::before {
  top: 0; left: 0;
  border-left: 3px solid rgb(0, 253, 127);
  border-bottom: 3px solid rgb(0, 255, 128);
}
.btn.hover-border-6 span::after {
  top: 0; right: 0;
  border-right: 3px solid rgb(0, 255, 128);
  border-bottom: 3px solid rgb(0, 255, 128);
}
.btn.hover-border-6 span:hover::before,
.btn.hover-border-6 span:hover::after {
  width: 50%; height: 96%;
  opacity: 1;
  transition: height 0.2s 0.2s ease-in, width 0.2s 0.4s linear, opacity 0s 0.2s;   
}

/* 17. hover-border-7 */
.btn.hover-border-7::before,
.btn.hover-border-7::after {
  bottom: 0;
  transition: width 0.2s 0.35s ease-out;
}
.btn.hover-border-7::before {
  right: 50%;
}
.btn.hover-border-7::after {
  left: 50%;
}
.btn.hover-border-7:hover::before,
.btn.hover-border-7:hover::after {
  width: 50%;
  transition: width 0.2s ease-in;   
}

.btn.hover-border-7 span::before,
.btn.hover-border-7 span::after {
  width: 0%; height: 0%;
  background: transparent;
  opacity: 0;
  z-index: 2;
  transition: width 0.2s ease-in, height 0.15s 0.2s linear, opacity 0s 0.35s;
}
.btn.hover-border-7 span::before {
  bottom: 0; left: 0;
  border-left: 3px solid rgb(0, 255, 128);
  border-top: 3px solid rgb(0, 255, 128);
}
.btn.hover-border-7 span::after {
  bottom: 0; right: 0;
  border-right: 3px solid rgb(0, 255, 128);
  border-top: 3px solid rgb(0, 255, 128);
}
.btn.hover-border-7 span:hover::before,
.btn.hover-border-7 span:hover::after {
  width: 50%; height: 96%;
  opacity: 1;
  transition: height 0.2s 0.2s ease-in, width 0.2s 0.4s linear, opacity 0s 0.2s;   
}

</style>
