'''
https://flask-restful.readthedocs.io/en/latest/
1. pip install flask
2. pip install flask-restful
3. pip install flask_cors
'''
from flask import Flask
from flask_restful import Api
from flask_cors import CORS
import os

#플라스크 앱 생성
app = Flask(__name__)
#CORS에러 처리
CORS(app)


UPLOAD_ROOT=os.getcwd()
app.config['UPLOAD_FOLDER']=os.path.join(UPLOAD_ROOT, 'uploads')
app.config['MAX_CONTENT_LENGTH']= 1* 1024 * 1024
api = Api(app)

from api.mask_detection import MaskDetection
api.add_resource(MaskDetection,'/mask')
if __name__ == '__main__':
    app.run(debug=True)