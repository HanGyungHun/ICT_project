'''
python -m pip install --upgrade pip
pip install ultralytics
pip install pillow
pip install opencv-python
'''
from flask_restful import Resource
from flask import request,make_response
import base64
from PIL import Image
import json
import io
import os
from ultralytics import YOLO


class MaskDetection(Resource):
    def __init__(self):
        #모델 로드(#파일(best.pt)은 프로젝트 루트에)
        #커스텀 이미지로 사전 학습된 모델 로드
        self.model = YOLO('best.pt')
    def post(self):
        #경로 작성시 포로젝트 폴더 기준
        base64Encoded = request.form['base64Encoded']
        # base64 이미지 인코딩 문자열을 decode
        image_b64 = base64.b64decode(base64Encoded)
        image_memory = Image.open(io.BytesIO(image_b64))#이미지 파일로 디코딩
        image_memory.save('./images/new.jpg')#물리적으로 이미지 저장
        results = self.model.predict(['./images/new.jpg'],save=True)
        print('results\n',results)
        print('results[0].save_dir\n', results[0].save_dir)
        with open(os.path.join(results[0].save_dir, 'new.jpg'),'rb') as f:
            base64Predicted= base64.b64encode(f.read()).decode('utf-8')
        print('base64Predicted\n',base64Predicted)
        return make_response(json.dumps({'base64':base64Predicted},ensure_ascii=False))